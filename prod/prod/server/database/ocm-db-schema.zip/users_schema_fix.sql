-- Users table schema fix
-- This file adds missing columns to the existing users table

-- Add missing columns if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS role ENUM('admin', 'supervisor', 'priest', 'volunteer', 'viewer') DEFAULT 'viewer' AFTER email;

ALTER TABLE users 
ADD COLUMN IF NOT EXISTS landing_page VARCHAR(255) DEFAULT '/pages/welcome' AFTER role;

-- Update existing users to have admin role if they don't have one
UPDATE users SET role = 'admin' WHERE role IS NULL OR role = '';

-- Optional: Create the users table if it doesn't exist at all
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(255),
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'supervisor', 'priest', 'volunteer', 'viewer') DEFAULT 'viewer',
  landing_page VARCHAR(255) DEFAULT '/pages/welcome',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL,
  is_active BOOLEAN DEFAULT TRUE,
  name VARCHAR(255),
  phone VARCHAR(20),
  church_id INT,
  permissions JSON,
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_church_id (church_id)
);

-- Insert default admin user if no users exist
INSERT IGNORE INTO users (email, username, password_hash, role, landing_page) 
VALUES ('admin', 'admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXIG.QVuQhWm', 'admin', '/pages/admin/dashboard');
-- Default password is 'admin123'
