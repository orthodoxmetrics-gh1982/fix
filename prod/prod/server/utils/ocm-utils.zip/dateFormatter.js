// server/utils/dateFormatter.js
// Utility functions for cleaning up MySQL date/datetime formatting

/**
 * Format a date to YYYY-MM-DD format
 * @param {Date|string} date - The date to format
 * @returns {string|null} - Formatted date string or null
 */
function formatDate(date) {
  if (!date) return null;
  
  const dateObj = new Date(date);
  
  // Check if date is valid
  if (isNaN(dateObj.getTime())) return null;
  
  // Return just the date part in YYYY-MM-DD format
  return dateObj.toISOString().split('T')[0];
}

/**
 * Format a datetime to readable format
 * @param {Date|string} date - The datetime to format
 * @returns {string|null} - Formatted datetime string or null
 */
function formatDateTime(date) {
  if (!date) return null;
  
  const dateObj = new Date(date);
  
  // Check if date is valid
  if (isNaN(dateObj.getTime())) return null;
  
  // Return in format: "2025-07-03 7:05 PM"
  return dateObj.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit', 
    day: '2-digit',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

/**
 * Clean up common date fields in a record object
 * @param {Object} record - The record to clean
 * @returns {Object} - Record with cleaned date fields
 */
function cleanRecord(record) {
  if (!record || typeof record !== 'object') return record;
  
  const cleaned = { ...record };
  
  // Common date fields to format as dates
  const dateFields = ['birth_date', 'mdate', 'date', 'due_date', 'start_date', 'end_date', 'trial_end'];
  dateFields.forEach(field => {
    if (cleaned[field]) {
      cleaned[field] = formatDate(cleaned[field]);
    }
  });
  
  // Common datetime fields to format as readable datetimes
  const datetimeFields = ['created_at', 'updated_at', 'date_entered', 'last_login', 'cancelled_at', 'paid_at'];
  datetimeFields.forEach(field => {
    if (cleaned[field]) {
      cleaned[field] = formatDateTime(cleaned[field]);
    }
  });
  
  return cleaned;
}

/**
 * Clean up an array of records
 * @param {Array} records - Array of records to clean
 * @returns {Array} - Array of cleaned records
 */
function cleanRecords(records) {
  if (!Array.isArray(records)) return records;
  return records.map(cleanRecord);
}

module.exports = {
  formatDate,
  formatDateTime,
  cleanRecord,
  cleanRecords
};
