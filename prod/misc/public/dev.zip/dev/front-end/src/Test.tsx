// Test file to check if React types are working
import React from 'react';

const TestComponent: React.FC = () => {
  return <div>Test</div>;
};

export default TestComponent;
