
import ModernInvoiceEdit from './ModernInvoiceEdit.simple';

const EditInvoicePage = () => {
  return <ModernInvoiceEdit />;
};

export default EditInvoicePage;
