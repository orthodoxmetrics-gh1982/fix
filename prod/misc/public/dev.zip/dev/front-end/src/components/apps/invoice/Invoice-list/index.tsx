import ModernInvoiceList from './ModernInvoiceList';

export default ModernInvoiceList;