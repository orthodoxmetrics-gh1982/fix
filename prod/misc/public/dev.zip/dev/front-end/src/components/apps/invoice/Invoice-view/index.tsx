import React from 'react';
import InvoiceViewByNumber from './InvoiceViewByNumber';

const InvoiceView: React.FC = () => {
    return <InvoiceViewByNumber />;
};

export default InvoiceView;
