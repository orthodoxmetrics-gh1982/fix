import ModernInvoiceDetail from './ModernInvoiceDetail.simple';

const InvoiceDetail = () => {
  return <ModernInvoiceDetail />;
};

export default InvoiceDetail;
