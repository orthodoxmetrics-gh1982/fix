// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import * as React from 'react';

const Welcome = () => {
  // Welcome message disabled
  return null;
};

export default Welcome;
