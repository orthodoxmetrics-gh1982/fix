/**
 * Authentication Service for Orthodox Metrics
 * Updated to use the new userAPI with session-based authentication
 */

import { userAPI } from '../api/user.api';
import {
  User,
  AuthResponse,
  LoginCredentials,
} from '../types/orthodox-metrics.types';

// Legacy auth types for backward compatibility
import {
  RegisterData,
  ForgotPasswordData,
  ResetPasswordData,
} from '../types/auth/auth';

export class AuthService {
  /**
   * Login user with email and password
   */
  static async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      const response = await userAPI.auth.login(credentials);

      // Backend returns { success: true, user: {...}, message: "..." }
      if (response.success && response.user) {
        // Store user data (no tokens needed for session-based auth)
        localStorage.setItem('auth_user', JSON.stringify(response.user));

        return response;
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (error: any) {
      const message = error.message || 'Login failed';
      throw new Error(message);
    }
  }

  /**
   * Logout user
   */
  static async logout(): Promise<void> {
    try {
      await userAPI.auth.logout();
    } catch (error) {
      // Continue with logout even if API call fails
      console.error('Logout API error:', error);
    } finally {
      // Clear local storage (only user data for session-based auth)
      localStorage.removeItem('auth_user');
    }
  }

  /**
   * Request password reset
   */
  static async forgotPassword(data: ForgotPasswordData): Promise<void> {
    try {
      await userAPI.auth.forgotPassword(data.email);
    } catch (error: any) {
      throw new Error(error.message || 'Password reset request failed');
    }
  }

  /**
   * Reset password with token
   */
  static async resetPassword(data: ResetPasswordData): Promise<void> {
    try {
      await userAPI.auth.resetPassword(data.token, data.password);
    } catch (error: any) {
      throw new Error(error.message || 'Password reset failed');
    }
  }

  /**
   * Check current authentication status
   */
  static async checkAuth(): Promise<{ user: User | null; authenticated: boolean }> {
    try {
      const response = await userAPI.auth.checkAuth();

      if (response.authenticated && response.user) {
        // Update stored user data
        localStorage.setItem('auth_user', JSON.stringify(response.user));
        return {
          user: response.user,
          authenticated: true
        };
      } else {
        localStorage.removeItem('auth_user');
        return {
          user: null,
          authenticated: false
        };
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('auth_user');
      return {
        user: null,
        authenticated: false
      };
    }
  }

  /**
   * Get current user from stored data
   */
  static async getCurrentUser(): Promise<User> {
    try {
      const response = await userAPI.auth.checkAuth();
      
      if (response.authenticated && response.user) {
        return response.user;
      } else {
        throw new Error('User not authenticated');
      }
    } catch (error: any) {
      throw new Error(error.message || 'Failed to get current user');
    }
  }

  /**
   * Update user profile
   */
  static async updateProfile(userData: Partial<User>): Promise<User> {
    try {
      // This would need to be implemented in the userAPI if not already present
      throw new Error('Profile update not implemented in userAPI yet');
    } catch (error: any) {
      throw new Error(error.message || 'Profile update failed');
    }
  }

  /**
   * Change user password
   */
  static async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    try {
      // This would need to be implemented in the userAPI if not already present
      throw new Error('Password change not implemented in userAPI yet');
    } catch (error: any) {
      throw new Error(error.message || 'Password change failed');
    }
  }

  /**
   * Verify email with token
   */
  static async verifyEmail(token: string): Promise<void> {
    try {
      // This would need to be implemented in the userAPI if not already present
      throw new Error('Email verification not implemented in userAPI yet');
    } catch (error: any) {
      throw new Error(error.message || 'Email verification failed');
    }
  }

  /**
   * Resend verification email
   */
  static async resendVerification(): Promise<void> {
    try {
      // This would need to be implemented in the userAPI if not already present
      throw new Error('Resend verification not implemented in userAPI yet');
    } catch (error: any) {
      throw new Error(error.message || 'Failed to resend verification');
    }
  }

  /**
   * Get stored user data from localStorage
   */
  static getStoredUser(): User | null {
    try {
      const stored = localStorage.getItem('auth_user');
      return stored ? JSON.parse(stored) : null;
    } catch (error) {
      console.error('Error parsing stored user data:', error);
      return null;
    }
  }

  /**
   * Check if user is authenticated based on stored data
   */
  static isAuthenticated(): boolean {
    return this.getStoredUser() !== null;
  }
}

export default AuthService;
