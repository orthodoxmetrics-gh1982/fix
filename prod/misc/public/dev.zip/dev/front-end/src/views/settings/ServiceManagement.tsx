import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Alert,
    Card,
    CardContent,
    Stack,
    Button,
    CircularProgress,
    Grid,
    Chip,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    IconButton,
    Tooltip,
    Snackbar,
    LinearProgress,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Switch,
    FormControlLabel
} from '@mui/material';
import {
    IconServer,
    IconDatabase,
    IconRefresh,
    IconPlayerPlay,
    IconPlayerStop,
    IconAlertTriangle,
    IconCheck,
    IconX,
    IconClock,
    IconBuildingFactory,
    IconCode,
    IconActivity,
    IconSettings,
    IconTerminal,
    IconCloudDownload,
    IconEye,
    IconReload,
    IconChevronDown,
    IconChevronUp
} from '@tabler/icons-react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../contexts/NotificationContext';
import { adminAPI } from '../../api/admin.api';

interface ServiceStatus {
    name: string;
    displayName: string;
    status: 'running' | 'stopped' | 'error' | 'unknown';
    pid?: number;
    uptime?: string;
    cpu?: number;
    memory?: number;
    lastRestart?: string;
    description: string;
    category: 'core' | 'worker' | 'frontend' | 'database';
    restartable: boolean;
    logs?: string[];
    port?: number;
}

interface ServiceAction {
    service: string;
    action: 'start' | 'stop' | 'restart' | 'reload';
    timestamp: string;
    success: boolean;
    message?: string;
}

interface SystemHealth {
    overall: 'healthy' | 'warning' | 'critical';
    servicesUp: number;
    servicesTotal: number;
    lastUpdate: string;
    criticalServices: string[];
}

const ServiceManagement: React.FC = () => {
    const { isSuperAdmin } = useAuth();
    const { fetchNotifications, fetchCounts } = useNotifications();
    const [services, setServices] = useState<ServiceStatus[]>([]);
    const [systemHealth, setSystemHealth] = useState<SystemHealth | null>(null);
    const [recentActions, setRecentActions] = useState<ServiceAction[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);
    const [autoRefresh, setAutoRefresh] = useState(true);
    const [confirmDialog, setConfirmDialog] = useState<{
        open: boolean;
        service: string;
        action: string;
    }>({ open: false, service: '', action: '' });
    const [frontendBuilding, setFrontendBuilding] = useState(false);
    const [buildProgress, setBuildProgress] = useState<{
        phase: string;
        progress: number;
        estimatedTime: number;
        startTime: number | null;
        refreshCountdown: number | null;
    }>({
        phase: '',
        progress: 0,
        estimatedTime: 0,
        startTime: null,
        refreshCountdown: null
    });
    const [logsDialog, setLogsDialog] = useState<{
        open: boolean;
        service: string;
        logs: string[];
        loading: boolean;
    }>({ open: false, service: '', logs: [], loading: false });
    const [expandedActions, setExpandedActions] = useState<Set<number>>(new Set());
    const [removedActions, setRemovedActions] = useState<Set<number>>(new Set());

    useEffect(() => {
        if (isSuperAdmin()) {
            fetchServiceStatus();
            fetchSystemHealth();
            fetchRecentActions();
        }
    }, [isSuperAdmin]);

    // Auto-refresh every 10 seconds
    useEffect(() => {
        if (!autoRefresh || !isSuperAdmin()) return;

        const interval = setInterval(() => {
            fetchServiceStatus();
            fetchSystemHealth();
        }, 10000);

        return () => clearInterval(interval);
    }, [autoRefresh, isSuperAdmin]);

    // Update build progress timer
    useEffect(() => {
        if (!frontendBuilding || !buildProgress.startTime) return;

        const timer = setInterval(() => {
            setBuildProgress(prev => ({ ...prev })); // Force re-render to update elapsed time
        }, 1000);

        return () => clearInterval(timer);
    }, [frontendBuilding, buildProgress.startTime]);

    const fetchServiceStatus = async () => {
        try {
            const response = await adminAPI.services.getStatus();
            setServices(response.services || []);
        } catch (err: any) {
            setError(err.message || 'Failed to load service status');
        }
    };

    const fetchSystemHealth = async () => {
        try {
            const response = await adminAPI.services.getHealth();
            setSystemHealth(response);
        } catch (err: any) {
            console.error('Failed to fetch system health:', err);
        }
    };

    const fetchRecentActions = async () => {
        try {
            const response = await adminAPI.services.getRecentActions();
            setRecentActions(response.actions || []);
        } catch (err: any) {
            console.error('Failed to fetch recent actions:', err);
        }
    };

    const handleServiceAction = async (serviceName: string, action: string) => {
        setLoading(true);
        setError(null);
        
        try {
            const response = await adminAPI.services.performAction(serviceName, action);

            if (response.success) {
                setSuccess(`Successfully ${action}ed ${serviceName}`);
                fetchServiceStatus();
                fetchRecentActions();
            } else {
                throw new Error(response.message || `Failed to ${action} ${serviceName}`);
            }
        } catch (err: any) {
            setError(err.message || `Failed to ${action} service`);
        } finally {
            setLoading(false);
            setConfirmDialog({ open: false, service: '', action: '' });
        }
    };

    const pollForBuildCompletion = async () => {
        let pollCount = 0;
        const maxPolls = 30; // 5 minutes max (10 seconds * 30)
        
        const checkCompletion = async () => {
            try {
                // Check backend logs for completion message
                const response = await adminAPI.services.getBackendLogs(50);

                if (response.success) {
                    const logs = response.logs || [];
                    
                    // Look for build completion messages
                    const hasSuccess = logs.some(log => 
                        log.includes('🎉 FRONTEND BUILD COMPLETED SUCCESSFULLY 🎉') ||
                        log.includes('✅ Build process completed successfully')
                    );
                    
                    const hasFailure = logs.some(log => 
                        log.includes('🚨 FRONTEND BUILD FAILED 🚨') ||
                        log.includes('❌ Build process failed')
                    );
                    
                    if (hasSuccess || hasFailure) {
                        // Build completed - update UI
                        setBuildProgress(prev => ({
                            ...prev,
                            phase: hasSuccess ? 'Build completed! Refreshing page...' : 'Build failed - check logs',
                            progress: 100
                        }));
                        
                        if (hasSuccess) {
                            setSuccess('Frontend rebuild completed! Page will refresh automatically...');
                            
                            // Refresh notifications to show build completion
                            fetchNotifications();
                            fetchCounts();
                            
                            // Start countdown
                            setBuildProgress(prev => ({
                                ...prev,
                                refreshCountdown: 3
                            }));
                            
                            // Countdown timer
                            let countdown = 3;
                            const countdownInterval = setInterval(() => {
                                countdown--;
                                setBuildProgress(prev => ({
                                    ...prev,
                                    phase: `Build completed! Refreshing page in ${countdown}s...`,
                                    refreshCountdown: countdown
                                }));
                                
                                if (countdown <= 0) {
                                    clearInterval(countdownInterval);
                                    window.location.reload();
                                }
                            }, 1000);
                        } else {
                            setError('Frontend build failed. Check backend logs for details.');
                            
                            // Refresh notifications to show build failure
                            fetchNotifications();
                            fetchCounts();
                            
                            setFrontendBuilding(false);
                            setBuildProgress({
                                phase: '',
                                progress: 0,
                                estimatedTime: 0,
                                startTime: null,
                                refreshCountdown: null
                            });
                        }
                        return; // Stop polling
                    }
                }
                
                // Continue polling if not complete and under max polls
                pollCount++;
                if (pollCount < maxPolls) {
                    setTimeout(checkCompletion, 10000); // Check every 10 seconds
                } else {
                    // Timeout - stop polling
                    setError('Build status check timed out. Please check manually.');
                    setFrontendBuilding(false);
                    setBuildProgress({
                        phase: '',
                        progress: 0,
                        estimatedTime: 0,
                        startTime: null,
                        refreshCountdown: null
                    });
                }
                
            } catch (error) {
                console.error('Error checking build completion:', error);
                pollCount++;
                if (pollCount < maxPolls) {
                    setTimeout(checkCompletion, 10000); // Continue polling on error
                }
            }
        };
        
        // Start polling
        checkCompletion();
    };

    const handleFrontendRebuild = async () => {
        setFrontendBuilding(true);
        setError(null);
        setSuccess(null);
        const startTime = Date.now();
        setBuildProgress({
            phase: 'Initializing build...',
            progress: 0,
            estimatedTime: 60, // 1 minute estimated
            startTime,
            refreshCountdown: null
        });
        
        // Simulate build progress
        const progressSteps = [
            { phase: 'Analyzing modules...', progress: 25, delay: 2000 },
            { phase: 'Building components...', progress: 50, delay: 3000 },
            { phase: 'Optimizing assets...', progress: 75, delay: 2000 },
            { phase: 'Finalizing build...', progress: 95, delay: 1500 }
        ];
        
        let progressTimeout: NodeJS.Timeout;
        let currentStep = 0;
        
        const updateProgress = () => {
            if (currentStep < progressSteps.length) {
                const step = progressSteps[currentStep];
                setBuildProgress(prev => ({
                    ...prev,
                    phase: step.phase,
                    progress: step.progress
                }));
                currentStep++;
                progressTimeout = setTimeout(updateProgress, step.delay);
            }
        };
        
        // Start progress simulation
        progressTimeout = setTimeout(updateProgress, 1000);
        
        try {
            const response = await adminAPI.services.rebuildFrontend();

            if (response.success) {
                const data = response;
                
                // Refresh notifications to show build start notification
                fetchNotifications();
                fetchCounts();
                
                // Complete the progress
                setBuildProgress(prev => ({
                    ...prev,
                    phase: 'Build completed successfully!',
                    progress: 100
                }));
                
                // Start polling for actual build completion
                setTimeout(() => {
                    pollForBuildCompletion();
                }, 2000);
                
                fetchRecentActions();
            } else {
                clearTimeout(progressTimeout);
                const errorData = response;
                throw new Error(errorData.message || 'Failed to trigger frontend rebuild');
            }
        } catch (err: any) {
            clearTimeout(progressTimeout);
            setError(err.message || 'Failed to rebuild frontend');
            setFrontendBuilding(false);
            setBuildProgress({
                phase: '',
                progress: 0,
                estimatedTime: 0,
                startTime: null,
                refreshCountdown: null
            });
        }
    };

    const handleViewLogs = async (serviceName: string) => {
        setLogsDialog({ open: true, service: serviceName, logs: [], loading: true });
        
        try {
            const response = await adminAPI.services.getServiceLogs(serviceName, 100);

            if (response.success) {
                setLogsDialog({ 
                    open: true, 
                    service: serviceName, 
                    logs: response.logs || [], 
                    loading: false 
                });
            } else {
                const errorData = response;
                throw new Error(errorData.message || 'Failed to fetch logs');
            }
        } catch (err: any) {
            setError(err.message || 'Failed to fetch service logs');
            setLogsDialog({ open: false, service: '', logs: [], loading: false });
        }
    };

    const toggleActionExpanded = (index: number) => {
        setExpandedActions(prev => {
            const newSet = new Set(prev);
            if (newSet.has(index)) {
                newSet.delete(index);
            } else {
                newSet.add(index);
            }
            return newSet;
        });
    };

    const removeAction = (index: number) => {
        setRemovedActions(prev => new Set([...prev, index]));
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'running': return 'success';
            case 'stopped': return 'warning';
            case 'error': return 'error';
            default: return 'default';
        }
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'running': return <IconCheck size={16} />;
            case 'stopped': return <IconPlayerStop size={16} />;
            case 'error': return <IconX size={16} />;
            default: return <IconAlertTriangle size={16} />;
        }
    };

    const getCategoryIcon = (category: string) => {
        switch (category) {
            case 'core': return <IconServer size={20} />;
            case 'database': return <IconDatabase size={20} />;
            case 'worker': return <IconActivity size={20} />;
            case 'frontend': return <IconCode size={20} />;
            default: return <IconSettings size={20} />;
        }
    };

    const getHealthColor = (health: string) => {
        switch (health) {
            case 'healthy': return 'success';
            case 'warning': return 'warning';
            case 'critical': return 'error';
            default: return 'default';
        }
    };

    if (!isSuperAdmin()) {
        return (
            <Alert severity="error">
                Access denied. Only super administrators can manage services.
            </Alert>
        );
    }

    return (
        <Box>
            <Typography variant="h6" gutterBottom>
                Service Management
            </Typography>
            
            <Alert severity="info" sx={{ mb: 3 }}>
                Monitor and control essential OrthodoxMetrics services. Critical services are automatically monitored for 24/7 uptime.
            </Alert>

            {error && (
                <Alert severity="error" sx={{ mb: 3 }} action={
                    <Button color="inherit" size="small" onClick={fetchServiceStatus}>
                        Retry
                    </Button>
                }>
                    {error}
                </Alert>
            )}

            {/* System Health Overview */}
            {systemHealth && (
                <Card sx={{ mb: 3 }}>
                    <CardContent>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                            <Typography variant="h6">
                                System Health Overview
                            </Typography>
                            <Box display="flex" alignItems="center" gap={2}>
                                <FormControlLabel
                                    control={
                                        <Switch
                                            checked={autoRefresh}
                                            onChange={(e) => setAutoRefresh(e.target.checked)}
                                        />
                                    }
                                    label="Auto Refresh"
                                />
                                <Button
                                    variant="outlined"
                                    size="small"
                                    startIcon={<IconRefresh />}
                                    onClick={() => {
                                        fetchServiceStatus();
                                        fetchSystemHealth();
                                    }}
                                    disabled={loading}
                                >
                                    Refresh
                                </Button>
                            </Box>
                        </Box>

                        <Grid container spacing={3}>
                            <Grid item xs={12} md={3}>
                                <Box textAlign="center">
                                    <Chip
                                        label={systemHealth.overall.toUpperCase()}
                                        color={getHealthColor(systemHealth.overall)}
                                        size="large"
                                        icon={getStatusIcon(systemHealth.overall)}
                                    />
                                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                                        Overall Status
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} md={3}>
                                <Box textAlign="center">
                                    <Typography variant="h4">
                                        {systemHealth.servicesUp}/{systemHealth.servicesTotal}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Services Online
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} md={3}>
                                <Box textAlign="center">
                                    <Typography variant="h6">
                                        {systemHealth.criticalServices.length}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Critical Services
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} md={3}>
                                <Box textAlign="center">
                                    <Typography variant="body2">
                                        {new Date(systemHealth.lastUpdate).toLocaleTimeString()}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Last Updated
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
            )}

            {/* Service Control Actions */}
            <Card sx={{ mb: 3 }}>
                <CardContent>
                    <Typography variant="h6" gutterBottom>
                        Quick Actions
                    </Typography>
                    <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                        <Button
                            variant="contained"
                            startIcon={frontendBuilding ? <CircularProgress size={20} sx={{ color: 'white' }} /> : <IconBuildingFactory />}
                            onClick={handleFrontendRebuild}
                            disabled={frontendBuilding}
                            sx={{ 
                                minWidth: 160,
                                '&.Mui-disabled': {
                                    background: frontendBuilding ? 'primary.main' : undefined,
                                    color: frontendBuilding ? 'white' : undefined,
                                    opacity: frontendBuilding ? 0.8 : undefined
                                }
                            }}
                        >
                            {frontendBuilding ? 'Building Frontend...' : 'Rebuild Frontend'}
                        </Button>
                        <Button
                            variant="outlined"
                            startIcon={<IconReload />}
                            onClick={() => setConfirmDialog({ open: true, service: 'pm2', action: 'reload' })}
                        >
                            Reload PM2
                        </Button>
                        <Button
                            variant="outlined"
                            startIcon={<IconRefresh />}
                            onClick={() => setConfirmDialog({ open: true, service: 'nginx', action: 'restart' })}
                        >
                            Restart Nginx
                        </Button>
                    </Stack>
                </CardContent>
            </Card>

            {/* Build Progress Indicator */}
            {frontendBuilding && (
                <Card sx={{ mb: 3, border: '1px solid', borderColor: 'primary.main' }}>
                    <CardContent>
                        <Box sx={{ mb: 2 }}>
                            <Box display="flex" alignItems="center" justifyContent="space-between" mb={1}>
                                <Typography variant="h6" color="primary">
                                    Frontend Build in Progress
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    {buildProgress.startTime && (
                                        `${Math.floor((Date.now() - buildProgress.startTime) / 1000)}s elapsed`
                                    )}
                                </Typography>
                            </Box>
                            
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                {buildProgress.phase}
                            </Typography>
                            
                            <LinearProgress 
                                variant="determinate" 
                                value={buildProgress.progress} 
                                sx={{ 
                                    height: 8, 
                                    borderRadius: 4,
                                    backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                    '& .MuiLinearProgress-bar': {
                                        borderRadius: 4,
                                    }
                                }} 
                            />
                            
                            <Box display="flex" justifyContent="space-between" mt={1}>
                                <Typography variant="body2" color="text.secondary">
                                    {buildProgress.progress}% complete
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Est. {Math.max(0, buildProgress.estimatedTime - (buildProgress.startTime ? Math.floor((Date.now() - buildProgress.startTime) / 1000) : 0))}s remaining
                                </Typography>
                            </Box>
                        </Box>
                        
                        <Alert severity="info" sx={{ mt: 2 }}>
                            <Typography variant="body2" sx={{ mb: 1 }}>
                                <strong>Build Command:</strong> NODE_OPTIONS="--max-old-space-size=4096" npm run build
                            </Typography>
                            <Typography variant="body2" sx={{ mb: 1 }}>
                                <strong>Monitor Progress:</strong> Click "View Logs" on Backend Server below to see real build status
                            </Typography>
                            <Typography variant="body2" color="primary">
                                <strong>Auto-Refresh:</strong> Page will automatically refresh when build completes
                            </Typography>
                        </Alert>
                    </CardContent>
                </Card>
            )}

            {/* Services Table */}
            <Card sx={{ mb: 3 }}>
                <CardContent>
                    <Typography variant="h6" gutterBottom>
                        Service Status
                    </Typography>
                    <TableContainer component={Paper} variant="outlined">
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Service</TableCell>
                                    <TableCell>Status</TableCell>
                                    <TableCell>Resource Usage</TableCell>
                                    <TableCell>Uptime</TableCell>
                                    <TableCell>Last Restart</TableCell>
                                    <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {services.map((service) => (
                                    <TableRow 
                                        key={service.name}
                                        sx={frontendBuilding && service.name === 'backend' ? {
                                            backgroundColor: 'rgba(25, 118, 210, 0.08)',
                                            border: '1px solid rgba(25, 118, 210, 0.3)'
                                        } : {}}
                                    >
                                        <TableCell>
                                            <Box display="flex" alignItems="center" gap={1}>
                                                {getCategoryIcon(service.category)}
                                                <Box>
                                                    <Typography variant="body2" fontWeight="bold">
                                                        {service.displayName}
                                                    </Typography>
                                                    <Typography variant="caption" color="text.secondary">
                                                        {service.description}
                                                    </Typography>
                                                </Box>
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Chip
                                                label={service.status}
                                                color={getStatusColor(service.status)}
                                                size="small"
                                                icon={getStatusIcon(service.status)}
                                            />
                                            {service.pid && (
                                                <Typography variant="caption" display="block">
                                                    PID: {service.pid}
                                                </Typography>
                                            )}
                                        </TableCell>
                                        <TableCell>
                                            {service.cpu !== undefined && (
                                                <Box>
                                                    <Typography variant="caption">
                                                        CPU: {service.cpu.toFixed(1)}%
                                                    </Typography>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={service.cpu}
                                                        sx={{ height: 4, mb: 0.5 }}
                                                    />
                                                    <Typography variant="caption">
                                                        RAM: {service.memory?.toFixed(1)}MB
                                                    </Typography>
                                                </Box>
                                            )}
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {service.uptime || 'N/A'}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {service.lastRestart 
                                                    ? new Date(service.lastRestart).toLocaleString()
                                                    : 'Never'
                                                }
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Stack direction="row" spacing={1}>
                                                {service.restartable && service.status === 'running' && (
                                                    <Tooltip title="Restart Service">
                                                        <IconButton
                                                            size="small"
                                                            onClick={() => setConfirmDialog({
                                                                open: true,
                                                                service: service.name,
                                                                action: 'restart'
                                                            })}
                                                        >
                                                            <IconRefresh size={16} />
                                                        </IconButton>
                                                    </Tooltip>
                                                )}
                                                {service.restartable && service.status === 'stopped' && (
                                                    <Tooltip title="Start Service">
                                                        <IconButton
                                                            size="small"
                                                            onClick={() => setConfirmDialog({
                                                                open: true,
                                                                service: service.name,
                                                                action: 'start'
                                                            })}
                                                        >
                                                            <IconPlayerPlay size={16} />
                                                        </IconButton>
                                                    </Tooltip>
                                                )}
                                                {service.restartable && service.status === 'running' && (
                                                    <Tooltip title="Stop Service">
                                                        <IconButton
                                                            size="small"
                                                            onClick={() => setConfirmDialog({
                                                                open: true,
                                                                service: service.name,
                                                                action: 'stop'
                                                            })}
                                                        >
                                                            <IconPlayerStop size={16} />
                                                        </IconButton>
                                                    </Tooltip>
                                                )}
                                                <Tooltip title={
                                                    frontendBuilding && service.name === 'backend' 
                                                        ? "View Build Progress - Check for completion status!" 
                                                        : "View Logs"
                                                }>
                                                    <IconButton
                                                        size="small"
                                                        onClick={() => handleViewLogs(service.name)}
                                                        sx={frontendBuilding && service.name === 'backend' ? {
                                                            backgroundColor: 'primary.main',
                                                            color: 'white',
                                                            '&:hover': {
                                                                backgroundColor: 'primary.dark'
                                                            }
                                                        } : {}}
                                                    >
                                                        <IconEye size={16} />
                                                    </IconButton>
                                                </Tooltip>
                                            </Stack>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </CardContent>
            </Card>

            {/* Recent Actions */}
            {recentActions.filter((_, index) => !removedActions.has(index)).length > 0 && (
                <Card>
                    <CardContent>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                            <Typography variant="h6">
                                Recent Service Actions
                            </Typography>
                            <Button
                                size="small"
                                variant="outlined"
                                color="error"
                                startIcon={<IconX />}
                                onClick={() => {
                                    const allIndexes = recentActions.slice(0, 10).map((_, index) => index);
                                    setRemovedActions(new Set(allIndexes));
                                }}
                                sx={{ fontSize: '0.75rem' }}
                            >
                                Clear All
                            </Button>
                        </Box>
                        <Stack spacing={1}>
                            {recentActions
                                .slice(0, 10)
                                .map((action, index) => {
                                    if (removedActions.has(index)) return null;
                                    
                                    const isExpanded = expandedActions.has(index);
                                    const hasLongMessage = action.message && action.message.length > 100;
                                    const displayMessage = action.message ? 
                                        (hasLongMessage && !isExpanded ? 
                                            `${action.message.substring(0, 100)}...` : 
                                            action.message
                                        ) : '';

                                    return (
                                        <Card
                                            key={index}
                                            variant="outlined"
                                            sx={{
                                                border: `1px solid ${action.success ? 'success.main' : 'error.main'}`,
                                                backgroundColor: action.success ? 'success.light' : 'error.light',
                                                '&:hover': {
                                                    backgroundColor: action.success ? 'success.dark' : 'error.dark',
                                                }
                                            }}
                                        >
                                            <CardContent sx={{ py: 1, px: 2, '&:last-child': { pb: 1 } }}>
                                                {/* Header Row */}
                                                <Box display="flex" justifyContent="space-between" alignItems="center">
                                                    <Box display="flex" alignItems="center" gap={1} flex={1}>
                                                        <Chip
                                                            label={action.action.toUpperCase()}
                                                            size="small"
                                                            color={action.success ? 'success' : 'error'}
                                                            sx={{ fontWeight: 'bold' }}
                                                        />
                                                        <Typography variant="body2" fontWeight="medium">
                                                            {action.service}
                                                        </Typography>
                                                        <Typography variant="caption" color="text.secondary">
                                                            {new Date(action.timestamp).toLocaleString()}
                                                        </Typography>
                                                    </Box>
                                                    
                                                    <Box display="flex" alignItems="center" gap={1}>
                                                        {hasLongMessage && (
                                                            <IconButton
                                                                size="small"
                                                                onClick={() => toggleActionExpanded(index)}
                                                                sx={{ color: 'text.secondary' }}
                                                            >
                                                                {isExpanded ? <IconChevronUp size={16} /> : <IconChevronDown size={16} />}
                                                            </IconButton>
                                                        )}
                                                        <IconButton
                                                            size="small"
                                                            onClick={() => removeAction(index)}
                                                            sx={{ color: 'text.secondary' }}
                                                        >
                                                            <IconX size={16} />
                                                        </IconButton>
                                                    </Box>
                                                </Box>
                                                
                                                {/* Message Row */}
                                                {displayMessage && (
                                                    <Box mt={1}>
                                                        <Typography 
                                                            variant="body2" 
                                                            sx={{ 
                                                                fontFamily: 'monospace',
                                                                fontSize: '0.75rem',
                                                                wordBreak: 'break-word',
                                                                whiteSpace: 'pre-wrap',
                                                                backgroundColor: 'rgba(0,0,0,0.1)',
                                                                padding: 1,
                                                                borderRadius: 1,
                                                                maxHeight: isExpanded ? 'none' : '100px',
                                                                overflow: isExpanded ? 'visible' : 'hidden'
                                                            }}
                                                        >
                                                            {displayMessage}
                                                        </Typography>
                                                        {hasLongMessage && !isExpanded && (
                                                            <Button
                                                                size="small"
                                                                onClick={() => toggleActionExpanded(index)}
                                                                sx={{ mt: 0.5, fontSize: '0.7rem' }}
                                                            >
                                                                Show More
                                                            </Button>
                                                        )}
                                                    </Box>
                                                )}
                                            </CardContent>
                                        </Card>
                                    );
                                })
                                .filter(Boolean)}
                        </Stack>
                    </CardContent>
                </Card>
            )}

            {/* Confirmation Dialog */}
            <Dialog
                open={confirmDialog.open}
                onClose={() => setConfirmDialog({ open: false, service: '', action: '' })}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>
                    Confirm Service Action
                </DialogTitle>
                <DialogContent>
                    <Alert severity="warning" sx={{ mb: 2 }}>
                        Are you sure you want to {confirmDialog.action} the {confirmDialog.service} service?
                        This action may temporarily affect system availability.
                    </Alert>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setConfirmDialog({ open: false, service: '', action: '' })}>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        onClick={() => handleServiceAction(confirmDialog.service, confirmDialog.action)}
                        disabled={loading}
                    >
                        {loading ? 'Processing...' : `${confirmDialog.action.toUpperCase()}`}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Logs Dialog */}
            <Dialog
                open={logsDialog.open}
                onClose={() => setLogsDialog({ open: false, service: '', logs: [], loading: false })}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle>
                    <Stack direction="row" alignItems="center" spacing={2}>
                        <IconTerminal size={20} />
                        Service Logs: {logsDialog.service}
                        {logsDialog.loading && <CircularProgress size={16} />}
                    </Stack>
                </DialogTitle>
                <DialogContent>
                    {logsDialog.loading ? (
                        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                            <CircularProgress />
                        </Box>
                    ) : (
                        <Box
                            sx={{
                                bgcolor: 'grey.900',
                                color: 'common.white',
                                p: 2,
                                borderRadius: 1,
                                fontFamily: 'monospace',
                                fontSize: '0.875rem',
                                maxHeight: 400,
                                overflowY: 'auto',
                                minHeight: 200,
                                border: '1px solid',
                                borderColor: 'grey.700'
                            }}
                        >
                            {logsDialog.logs.length > 0 ? (
                                logsDialog.logs.map((log, index) => (
                                    <Typography 
                                        key={index} 
                                        component="div" 
                                        variant="body2"
                                        sx={{ 
                                            whiteSpace: 'pre-wrap',
                                            wordBreak: 'break-word',
                                            py: 0.25
                                        }}
                                    >
                                        {log}
                                    </Typography>
                                ))
                            ) : (
                                <Typography variant="body2" sx={{ color: 'grey.400', textAlign: 'center', py: 2 }}>
                                    No logs available
                                </Typography>
                            )}
                        </Box>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button 
                        onClick={() => handleViewLogs(logsDialog.service)}
                        disabled={logsDialog.loading}
                        startIcon={<IconRefresh />}
                    >
                        Refresh
                    </Button>
                    <Button onClick={() => setLogsDialog({ open: false, service: '', logs: [], loading: false })}>
                        Close
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Success Snackbar */}
            <Snackbar
                open={!!success}
                autoHideDuration={6000}
                onClose={() => setSuccess(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert severity="success" onClose={() => setSuccess(null)}>
                    {success}
                </Alert>
            </Snackbar>
        </Box>
    );
};

export default ServiceManagement; 