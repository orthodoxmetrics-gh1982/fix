/**
 * Orthodox Metrics - Church Management Create/Edit Form
 * Form for creating and editing church information
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import {
  Box,
  Grid,
  Typography,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Alert,
  Divider,
  Card,
  CardContent,
  CardHeader,
  IconButton,
  CircularProgress,
  Collapse,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  IconArrowLeft,
  IconDeviceFloppy,
  IconTrash,
} from '@tabler/icons-react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import PageContainer from 'src/components/container/PageContainer';
import Breadcrumb from 'src/layouts/full/shared/breadcrumb/Breadcrumb';
import { useAuth } from 'src/context/AuthContext';
import { orthodoxMetricsAPI } from 'src/api/orthodox-metrics.api';
import { logger } from 'src/utils/logger';
import type { SupportedLanguage } from 'src/types/orthodox-metrics.types';
import {
  Save as SaveIcon,
  Cancel as CancelIcon,
  ArrowBack as ArrowBackIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  People as PeopleIcon,
  Settings as SettingsIcon,
  Storage as StorageIcon,
  ExpandMore as ExpandMoreIcon,
  Edit as EditIcon,
  Lock as LockIcon,
  LockOpen as LockOpenIcon,
  VpnKey as VpnKeyIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Refresh as RefreshIcon,
  Schedule as ScheduleIcon,
  History as HistoryIcon,
} from '@mui/icons-material';
import UserManagementDialog from './UserManagementDialog';

const validationSchema = Yup.object({
  name: Yup.string().required('Church name is required').min(2, 'Name must be at least 2 characters'),
  email: Yup.string().email('Invalid email format').required('Email is required'),
  city: Yup.string(),
  state_province: Yup.string(),
  postal_code: Yup.string(),
  country: Yup.string(),
  preferred_language: Yup.string().required('Language preference is required'),
  timezone: Yup.string().required('Timezone is required'),
  currency: Yup.string(),
  tax_id: Yup.string(),
  church_id: Yup.number()
    .positive('Church ID must be a positive number')
    .integer('Church ID must be an integer')
    .nullable(),
});

interface ChurchFormProps { }

const ChurchForm: React.FC<ChurchFormProps> = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, hasRole } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [templateChurches, setTemplateChurches] = useState<any[]>([]);
  const [loadingTemplateChurches, setLoadingTemplateChurches] = useState(false);
  const [isFieldModified, setIsFieldModified] = useState<Record<string, boolean>>({});
  
  // Collapsible sections state
  const [expandedSections, setExpandedSections] = useState({
    users: false,
    advanced: false,
    database: false
  });
  
  // Church management data
  const [churchUsers, setChurchUsers] = useState<any[]>([]);
  const [recordCounts, setRecordCounts] = useState<Record<string, number>>({});
  const [databaseInfo, setDatabaseInfo] = useState<any>(null);
  const [databaseLogs, setDatabaseLogs] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [loadingRecords, setLoadingRecords] = useState(false);
  const [loadingDatabase, setLoadingDatabase] = useState(false);
  
  // User management dialogs
  const [userDialog, setUserDialog] = useState({ open: false, user: null, action: '' });
  const [passwordResetDialog, setPasswordResetDialog] = useState({ open: false, user: null });

  const isEdit = Boolean(id);

  // Handle form field changes with logging
  const handleFieldChange = (fieldName: string, value: any) => {
    setIsFieldModified(prev => ({ ...prev, [fieldName]: true }));
    
    // Log field change for important fields
    if (['name', 'email', 'preferred_language', 'timezone', 'is_active'].includes(fieldName)) {
      logger.info('Church Management', `Church form field updated: ${fieldName}`, {
        field: fieldName,
        value: typeof value === 'string' ? value : JSON.stringify(value),
        isEdit: isEdit,
        churchId: id,
        userAction: 'church_form_field_change'
      });
    }
  };

  // Load church users
  const loadChurchUsers = async (churchId: string) => {
    try {
      setLoadingUsers(true);
      const response = await fetch(`/api/admin/churches/${churchId}/users`, {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setChurchUsers(data.users || []);
      }
    } catch (error) {
      console.error('Error loading church users:', error);
    } finally {
      setLoadingUsers(false);
    }
  };

  // Load record counts
  const loadRecordCounts = async (churchId: string) => {
    try {
      setLoadingRecords(true);
      const response = await fetch(`/api/admin/churches/${churchId}/record-counts`, {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setRecordCounts(data.counts || {});
      }
    } catch (error) {
      console.error('Error loading record counts:', error);
    } finally {
      setLoadingRecords(false);
    }
  };

  // Load database information
  const loadDatabaseInfo = async (churchId: string) => {
    try {
      setLoadingDatabase(true);
      console.log('🔍 Loading database info for church ID:', churchId);
      
      const response = await fetch(`/api/admin/churches/${churchId}/database-info`, {
        credentials: 'include'
      });
      
      console.log('🔍 Database info response status:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('🔍 Database info response data:', data);
        console.log('🔍 Database object:', data.database);
        console.log('🔍 Database name:', data.database?.name);
        
        setDatabaseInfo(data.database || null);
        setDatabaseLogs(data.logs || []);
      } else {
        const errorText = await response.text();
        console.error('🔍 Database info API error:', response.status, errorText);
        setError(`Failed to load database info: ${response.status} ${errorText}`);
      }
    } catch (error) {
      console.error('🔍 Error loading database info:', error);
      setError(`Error loading database info: ${error.message}`);
    } finally {
      setLoadingDatabase(false);
    }
  };

  // Test database connection
  const testDatabaseConnection = async (churchId: string) => {
    try {
      setLoadingDatabase(true);
      setError(null); // Clear any previous errors
      setSuccess(null); // Clear any previous success messages
      
      console.log('🔍 Testing database connection for church ID:', churchId);
      
      const response = await fetch(`/api/admin/churches/${churchId}/test-connection`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      console.log('🔍 Test connection response status:', response.status);

      if (response.ok) {
        const data = await response.json();
        console.log('🔍 Test connection response data:', data);
        
        if (data.success && data.data?.connection) {
          const connection = data.data.connection;
          setSuccess(`Database connection successful! Connection time: ${connection.connection_time_ms}ms`);
          // Refresh database info after successful test
          await loadDatabaseInfo(churchId);
        } else {
          setError(`Database connection failed: ${data.error || 'Unknown error'}`);
        }
      } else {
        const errorText = await response.text();
        console.error('🔍 Test connection API error:', response.status, errorText);
        setError(`Failed to test database connection: ${response.status} ${errorText}`);
      }
    } catch (error) {
      console.error('🔍 Error testing database connection:', error);
      setError(`Error testing database connection: ${error.message}`);
    } finally {
      setLoadingDatabase(false);
    }
  };

  // Handle section expansion
  const handleSectionToggle = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));

    // Load data when section is expanded for the first time
    if (!expandedSections[section] && isEdit && id) {
      switch (section) {
        case 'users':
          loadChurchUsers(id);
          break;
        case 'advanced':
          loadRecordCounts(id);
          break;
        case 'database':
          loadDatabaseInfo(id);
          break;
      }
    }
  };

  // User management functions
  const handleUserAction = async (user: any, action: string) => {
    try {
      const response = await fetch(`/api/admin/churches/${id}/users/${user.id}/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });

      if (response.ok) {
        setSuccess(`User ${action} successful`);
        loadChurchUsers(id!);
      } else {
        throw new Error(`Failed to ${action} user`);
      }
    } catch (error) {
      setError(`Error: ${error.message}`);
    }
  };

  const handlePasswordReset = async (user: any) => {
    try {
      const response = await fetch(`/api/admin/churches/${id}/users/${user.id}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        setSuccess(`Password reset for ${user.email}. New password: ${data.newPassword}`);
      } else {
        throw new Error('Failed to reset password');
      }
    } catch (error) {
      setError(`Error resetting password: ${error.message}`);
    }
  };

  // Handle user save (add/edit)
  const handleUserSave = async (userData: any) => {
    try {
      const endpoint = userDialog.action === 'add' 
        ? `/api/admin/churches/${id}/users`
        : `/api/admin/churches/${id}/users/${userDialog.user?.id}`;
      
      const method = userDialog.action === 'add' ? 'POST' : 'PUT';

      const response = await fetch(endpoint, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(userData)
      });

      if (response.ok) {
        setSuccess(`User ${userDialog.action === 'add' ? 'added' : 'updated'} successfully`);
        // Refresh the users list if we're in edit mode
        if (expandedSections.users && id) {
          loadChurchUsers(id);
        }
      } else {
        const data = await response.json();
        throw new Error(data.message || `Failed to ${userDialog.action} user`);
      }
    } catch (error) {
      setError(`Error ${userDialog.action === 'add' ? 'adding' : 'updating'} user: ${error.message}`);
    }
  };

  // Handle back button click
  const handleBackClick = () => {
    logger.info('Church Management', 'Church form back button clicked', {
      isEdit: isEdit,
      churchId: id,
      formChanged: formik.dirty,
      userAction: 'church_form_back'
    });
    
    navigate('/apps/church-management');
  };

  // Handle form reset
  const handleFormReset = () => {
    formik.resetForm();
    
    logger.info('Church Management', 'Church form reset', {
      isEdit: isEdit,
      churchId: id,
      userAction: 'church_form_reset'
    });
  };

  const BCrumb = [
    { to: '/', title: 'Home' },
    { to: '/apps/church-management', title: 'Church Management' },
    { title: isEdit ? 'Edit Church' : 'Create Church' },
  ];

  // Load English churches for template selection
  useEffect(() => {
    const fetchEnglishChurches = async () => {
      if (!isEdit) { // Only fetch for new churches
        try {
          setLoadingTemplateChurches(true);
          const response = await fetch('/api/admin/churches?preferred_language=en', {
            credentials: 'include'
          });

          if (!response.ok) {
            throw new Error('Failed to fetch template churches');
          }

          const data = await response.json();
          setTemplateChurches(data.churches || []);
        } catch (err) {
          console.error('Error fetching template churches:', err);
        } finally {
          setLoadingTemplateChurches(false);
        }
      }
    };

    fetchEnglishChurches();
  }, [isEdit]);

  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state_province: '',
      postal_code: '',
      country: '',
      preferred_language: 'en',
      timezone: 'UTC',
      currency: 'USD',
      tax_id: '',
      website: '',
      description_multilang: '',
      settings: '',
      is_active: true,
      database_name: '',
      has_baptism_records: true,
      has_marriage_records: true,
      has_funeral_records: true,
      setup_complete: false,
      template_church_id: null, // New template field
      default_landing_page: 'church_records', // Default to church records
      church_id: null, // Church ID for linkage with records
    },
    validationSchema,
    onSubmit: async (values) => {
      console.log('Submitting form with values:', values);
      try {
        setLoading(true);
        setError(null);
        setSuccess(null);

        // Log form submission start
        logger.info('Church Management', `Church form submission started: ${isEdit ? 'update' : 'create'}`, {
          churchName: values.name,
          churchEmail: values.email,
          isEdit: isEdit,
          churchId: id,
          userAction: isEdit ? 'church_update_submit' : 'church_create_submit'
        });

        const churchData = {
          ...values,
          preferred_language: values.preferred_language as SupportedLanguage,
          description_multilang: values.description_multilang,
          settings: values.settings,
          database_name: values.database_name,
          has_baptism_records: values.has_baptism_records,
          has_marriage_records: values.has_marriage_records,
          has_funeral_records: values.has_funeral_records,
          setup_complete: values.setup_complete,
          template_church_id: values.template_church_id, // Include template selection
          church_id: values.church_id, // Include church_id for database linkage
        };

        if (isEdit && id) {
          await adminAPI.churches.update(parseInt(id), churchData);
          setSuccess('Church updated successfully!');
          logger.info('Church Management', 'Church updated successfully', {
            churchId: id,
            churchName: formik.values.name,
            userAction: 'church_update'
          });
        } else {
          await adminAPI.churches.create(churchData);
          setSuccess('Church created successfully!');
          logger.info('Church Management', 'Church created successfully', {
            churchName: formik.values.name,
            userAction: 'church_create'
          });
        }

        // Log successful redirect
        logger.info('Church Management', 'Redirecting to church list after successful operation', {
          operation: isEdit ? 'update' : 'create',
          churchName: values.name,
          userAction: 'church_form_redirect'
        });

        // Redirect after success
        setTimeout(() => {
          navigate('/apps/church-management');
        }, 2000);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An error occurred';
        setError(errorMessage);
        
        // Log the error to the logging system
        logger.error('Church Management', `Church ${isEdit ? 'update' : 'creation'} failed`, {
          error: errorMessage,
          churchName: formik.values.name,
          churchEmail: formik.values.email,
          isEdit: isEdit,
          churchId: id,
          userAction: isEdit ? 'church_update' : 'church_create',
          formValues: formik.values
        });
      } finally {
        setLoading(false);
      }
    },
    validateOnBlur: true,
    validateOnChange: true,
    validate: (values) => {
      const errors = {};
      const validation = validationSchema.validateSync(values, { abortEarly: false });
      if (validation && validation.inner && validation.inner.length > 0) {
        validation.inner.forEach((err) => {
          errors[err.path] = err.message;
        });
        console.log('Formik validation errors:', errors);
      }
      return errors;
    },
  });

  // Load church data for editing
  useEffect(() => {
    if (isEdit && id) {
      const loadChurch = async () => {
        try {
          setLoading(true);
          
          // Log the start of church loading for edit
          logger.info('Church Management', 'Loading church data for editing', {
            churchId: id,
            userAction: 'church_load_for_edit_start'
          });
          
          const church = await adminAPI.churches.getById(parseInt(id));
          
          console.log('📋 Loaded church data for editing:', church);
          
          // Set all form values
          const churchValues = {
            name: church.name || '',
            email: church.email || '',
            phone: church.phone || '',
            address: church.address || '',
            city: church.city || '',
            state_province: church.state_province || '',
            postal_code: church.postal_code || '',
            country: church.country || '',
            preferred_language: church.preferred_language || 'en',
            timezone: church.timezone || 'UTC',
            currency: church.currency || 'USD',
            tax_id: church.tax_id || '',
            website: church.website || '',
            description_multilang: church.description_multilang || '',
            settings: church.settings || '',
            is_active: church.is_active ?? true,
            database_name: church.database_name || '',
            has_baptism_records: church.has_baptism_records ?? true,
            has_marriage_records: church.has_marriage_records ?? true,
            has_funeral_records: church.has_funeral_records ?? true,
            setup_complete: church.setup_complete ?? false,
            template_church_id: church.template_church_id || null,
            default_landing_page: church.default_landing_page || 'church_records',
            church_id: church.id || church.church_id || null, // Include church_id for database linkage
          };
          
          console.log('📝 Setting form values:', churchValues);
          
          // Use setValues to populate the form
          formik.setValues(churchValues);
          
          // Also set individual fields as a fallback
          Object.keys(churchValues).forEach(key => {
            formik.setFieldValue(key, churchValues[key]);
          });
          
          console.log('✅ Form values set, current formik values:', formik.values);
          
          // Log successful load
          logger.info('Church Management', 'Church data loaded successfully for editing', {
            churchId: id,
            churchName: church.name,
            userAction: 'church_load_for_edit_success'
          });
        } catch (err) {
          const errorMessage = err instanceof Error ? err.message : 'Failed to load church data';
          console.error('Error loading church for edit:', err);
          
          // Check if it's a 404 error (church not found)
          if (errorMessage.includes('404') || errorMessage.includes('not found')) {
            setError(`Church with ID ${id} not found. Available church: ID 14 (Saints Peter and Paul Orthodox Church). Please check the URL or navigate back to the church list.`);
            
            // Add a button to navigate to the existing church
            setTimeout(() => {
              if (window.confirm('Would you like to edit the available church (Saints Peter and Paul Orthodox Church) instead?')) {
                navigate('/apps/church-management/edit/14');
              } else {
                navigate('/apps/church-management');
              }
            }, 3000);
          } else {
            // For other errors, provide a user-friendly message with fallback
            setError(`Unable to load church data: ${errorMessage}. You can still create a new church with the form below.`);
          }
          
          // Log the error to the logging system
          logger.error('Church Management', 'Failed to load church data for editing', {
            error: errorMessage,
            churchId: id,
            userAction: 'church_load_for_edit',
            errorType: errorMessage.includes('404') ? 'not_found' : 'server_error'
          });
        } finally {
          setLoading(false);
        }
      };

      loadChurch();
    } else if (!isEdit) {
      // Log form opening for new church creation
      logger.info('Church Management', 'New church form opened', {
        userAction: 'church_form_open_create'
      });
    }
  }, [id, isEdit]);

  if (!hasRole('admin') && !hasRole('super_admin') && !hasRole('supervisor')) {
    // Log the access denied error
    logger.warn('Church Management', 'Access denied. Administrator privileges required to edit/create churches.', {
      userAction: 'church_form_access_denied',
      requiredRoles: ['admin', 'super_admin', 'supervisor'],
      path: window.location.pathname,
      isEdit: isEdit
    });
    
    return (
      <PageContainer title="Church Management" description="Church management system">
        <Alert severity="error">
          Access denied. Administrator privileges required.
        </Alert>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title={isEdit ? 'Edit Church' : 'Create Church'}
      description="Church management form"
    >
      <Breadcrumb title={isEdit ? 'Edit Church' : 'Create Church'} items={BCrumb} />

      <Grid container spacing={3}>
        {/* Header */}
        <Grid item xs={12}>
          <Box display="flex" alignItems="center" mb={3}>
            <IconButton onClick={handleBackClick} sx={{ mr: 2 }}>
              <IconArrowLeft />
            </IconButton>
            <Typography variant="h4" color="primary">
              {isEdit ? 'Edit Church' : 'Create New Church'}
            </Typography>
          </Box>
        </Grid>

        {/* Loading State */}
        {loading && (
          <Grid item xs={12}>
            <Box display="flex" justifyContent="center" my={4}>
              <CircularProgress />
            </Box>
          </Grid>
        )}

        {/* Error State */}
        {error && (
          <Grid item xs={12}>
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          </Grid>
        )}

        {/* Success State */}
        {success && (
          <Grid item xs={12}>
            <Alert severity="success" sx={{ mb: 2 }}>
              {success}
            </Alert>
          </Grid>
        )}

        {!loading && (
          <Grid item xs={12} lg={8}>
            <form onSubmit={formik.handleSubmit}>
              <Grid container spacing={3}>
                {/* Basic Information */}
                <Grid item xs={12}>
                  <Card>
                    <CardHeader
                      title="Basic Information"
                      subheader="Essential church details"
                    />
                    <CardContent>
                      <Grid container spacing={3}>
                        <Grid item xs={12} md={6}>
                          <TextField
                            fullWidth
                            id="name"
                            name="name"
                            label="Church Name *"
                            value={formik.values.name}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.name && Boolean(formik.errors.name)}
                            helperText={formik.touched.name && formik.errors.name}
                            variant="outlined"
                          />
                        </Grid>
                        <Grid item xs={12} md={6}>
                          <TextField
                            fullWidth
                            id="email"
                            name="email"
                            label="Email Address *"
                            type="email"
                            value={formik.values.email}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.email && Boolean(formik.errors.email)}
                            helperText={formik.touched.email && formik.errors.email}
                            variant="outlined"
                          />
                        </Grid>
                        <Grid item xs={12} md={6}>
                          <TextField
                            fullWidth
                            id="phone"
                            name="phone"
                            label="Phone Number"
                            value={formik.values.phone}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.phone && Boolean(formik.errors.phone)}
                            helperText={formik.touched.phone && formik.errors.phone}
                            variant="outlined"
                          />
                        </Grid>
                        <Grid item xs={12} md={6}>
                          <TextField
                            fullWidth
                            id="website"
                            name="website"
                            label="Website"
                            value={formik.values.website}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.website && Boolean(formik.errors.website)}
                            helperText={formik.touched.website && formik.errors.website}
                            variant="outlined"
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            id="address"
                            name="address"
                            label="Address"
                            multiline
                            rows={2}
                            value={formik.values.address}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.address && Boolean(formik.errors.address)}
                            helperText={formik.touched.address && formik.errors.address}
                            variant="outlined"
                          />
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>

                  {/* Location Information */}
                  <Grid item xs={12}>
                    <Card>
                      <CardHeader
                        title="Location Details"
                        subheader="Geographic information"
                      />
                      <CardContent>
                        <Grid container spacing={3}>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              id="city"
                              name="city"
                              label="City"
                              value={formik.values.city}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              error={formik.touched.city && Boolean(formik.errors.city)}
                              helperText={formik.touched.city && formik.errors.city}
                              variant="outlined"
                            />
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              id="state_province"
                              name="state_province"
                              label="State/Province"
                              value={formik.values.state_province}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              error={formik.touched.state_province && Boolean(formik.errors.state_province)}
                              helperText={formik.touched.state_province && formik.errors.state_province}
                              variant="outlined"
                            />
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              id="postal_code"
                              name="postal_code"
                              label="Postal Code"
                              value={formik.values.postal_code}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              error={formik.touched.postal_code && Boolean(formik.errors.postal_code)}
                              helperText={formik.touched.postal_code && formik.errors.postal_code}
                              variant="outlined"
                            />
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              id="country"
                              name="country"
                              label="Country *"
                              value={formik.values.country}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              error={formik.touched.country && Boolean(formik.errors.country)}
                              helperText={formik.touched.country && formik.errors.country}
                              variant="outlined"
                            />
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>

                  {/* Settings */}
                  <Grid item xs={12}>
                    <Card>
                      <CardHeader title="Settings" />
                      <CardContent>
                        <Grid container spacing={2}>
                          <Grid item xs={12}>
                            <FormControl fullWidth>
                              <InputLabel>Language Preference *</InputLabel>
                              <Select
                                name="preferred_language"
                                value={formik.values.preferred_language}
                                onChange={formik.handleChange}
                                label="Language Preference *"
                                error={formik.touched.preferred_language && Boolean(formik.errors.preferred_language)}
                              >
                                <MenuItem value="en">English</MenuItem>
                                <MenuItem value="gr">Greek</MenuItem>
                                <MenuItem value="ru">Russian</MenuItem>
                                <MenuItem value="ro">Romanian</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                          <Grid item xs={12}>
                            <FormControl fullWidth>
                              <InputLabel>Timezone *</InputLabel>
                              <Select
                                name="timezone"
                                value={formik.values.timezone}
                                onChange={formik.handleChange}
                                label="Timezone *"
                                error={formik.touched.timezone && Boolean(formik.errors.timezone)}
                              >
                                <MenuItem value="UTC">UTC</MenuItem>
                                <MenuItem value="America/New_York">Eastern Time</MenuItem>
                                <MenuItem value="America/Chicago">Central Time</MenuItem>
                                <MenuItem value="America/Denver">Mountain Time</MenuItem>
                                <MenuItem value="America/Los_Angeles">Pacific Time</MenuItem>
                                <MenuItem value="Europe/Athens">Athens</MenuItem>
                                <MenuItem value="Europe/Moscow">Moscow</MenuItem>
                                <MenuItem value="Europe/Bucharest">Bucharest</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                          
                          {/* Template Church Selection - Only show for new churches */}
                          {!isEdit && (
                            <Grid item xs={12}>
                              <FormControl fullWidth>
                                <InputLabel>Use Template From Existing Church</InputLabel>
                                {loadingTemplateChurches ? (
                                  <Box display="flex" alignItems="center" gap={1} sx={{ p: 2 }}>
                                    <CircularProgress size={16} />
                                    <Typography variant="body2" color="text.secondary">
                                      Loading template churches...
                                    </Typography>
                                  </Box>
                                ) : (
                                  <Select
                                    name="template_church_id"
                                    value={formik.values.template_church_id || ''}
                                    onChange={formik.handleChange}
                                    label="Use Template From Existing Church"
                                  >
                                    <MenuItem value="">
                                      <em>No template - Start from scratch</em>
                                    </MenuItem>
                                    {templateChurches.map((church) => (
                                      <MenuItem key={church.id} value={church.id}>
                                        {church.name} ({church.city ? `${church.city}, ` : ''}{church.country || 'Unknown location'})
                                      </MenuItem>
                                    ))}
                                  </Select>
                                )}
                              </FormControl>
                              
                              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                                Select an English-language church to use as a template. The new church will inherit its structure, pages, themes, permissions, and settings.
                              </Typography>
                              
                              {formik.values.template_church_id && (
                                <Alert severity="info" sx={{ mt: 2 }}>
                                  <strong>📋 Template Selected:</strong> The new church will be created using the same structure and settings as the selected template church. This ensures consistent operation and seamless integration.
                                </Alert>
                              )}
                            </Grid>
                          )}
                          
                          <Grid item xs={12}>
                            <FormControlLabel
                              control={
                                <Switch
                                  checked={formik.values.is_active}
                                  onChange={(e) => {
                                    formik.setFieldValue('is_active', e.target.checked);
                                    handleFieldChange('is_active', e.target.checked);
                                  }}
                                  name="is_active"
                                />
                              }
                              label="Active"
                            />
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>

                  {/* Collapsible Sections for Edit Mode */}
                  {isEdit && (
                    <>
                      {/* Users Section */}
                      <Grid item xs={12}>
                        <Accordion 
                          expanded={expandedSections.users} 
                          onChange={() => handleSectionToggle('users')}
                        >
                          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                            <Box display="flex" alignItems="center">
                              <PeopleIcon sx={{ mr: 1, color: 'primary.main' }} />
                              <Typography variant="h6">Users</Typography>
                              {churchUsers.length > 0 && (
                                <Chip 
                                  label={`${churchUsers.length} users`} 
                                  size="small" 
                                  sx={{ ml: 2 }} 
                                />
                              )}
                            </Box>
                          </AccordionSummary>
                          <AccordionDetails>
                            {loadingUsers ? (
                              <Box display="flex" justifyContent="center" p={3}>
                                <CircularProgress />
                              </Box>
                            ) : (
                              <Box>
                                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                  <Typography variant="subtitle1">Church Users</Typography>
                                  <Button
                                    startIcon={<AddIcon />}
                                    onClick={() => setUserDialog({ open: true, user: null, action: 'add' })}
                                  >
                                    Add User
                                  </Button>
                                </Box>
                                
                                {churchUsers.length === 0 ? (
                                  <Alert severity="info">No users assigned to this church yet.</Alert>
                                ) : (
                                  <TableContainer component={Paper}>
                                    <Table>
                                      <TableHead>
                                        <TableRow>
                                          <TableCell>Name</TableCell>
                                          <TableCell>Email</TableCell>
                                          <TableCell>Role</TableCell>
                                          <TableCell>Status</TableCell>
                                          <TableCell>Last Login</TableCell>
                                          <TableCell>Actions</TableCell>
                                        </TableRow>
                                      </TableHead>
                                      <TableBody>
                                        {churchUsers.map((user) => (
                                          <TableRow key={user.id}>
                                            <TableCell>{user.first_name} {user.last_name}</TableCell>
                                            <TableCell>{user.email}</TableCell>
                                            <TableCell>
                                              <Chip 
                                                label={user.role} 
                                                size="small" 
                                                color={user.role === 'admin' ? 'error' : 'default'}
                                              />
                                            </TableCell>
                                            <TableCell>
                                              <Chip 
                                                label={user.is_active ? 'Active' : 'Locked'} 
                                                size="small" 
                                                color={user.is_active ? 'success' : 'error'}
                                              />
                                            </TableCell>
                                            <TableCell>
                                              {user.last_login ? new Date(user.last_login).toLocaleDateString() : 'Never'}
                                            </TableCell>
                                            <TableCell>
                                              <Box display="flex" gap={1}>
                                                <IconButton 
                                                  size="small" 
                                                  onClick={() => setUserDialog({ open: true, user, action: 'edit' })}
                                                  title="Edit User"
                                                >
                                                  <EditIcon />
                                                </IconButton>
                                                <IconButton 
                                                  size="small" 
                                                  onClick={() => handlePasswordReset(user)}
                                                  title="Reset Password"
                                                >
                                                  <VpnKeyIcon />
                                                </IconButton>
                                                <IconButton 
                                                  size="small" 
                                                  onClick={() => handleUserAction(user, user.is_active ? 'lock' : 'unlock')}
                                                  title={user.is_active ? 'Lock Account' : 'Unlock Account'}
                                                >
                                                  {user.is_active ? <LockIcon /> : <LockOpenIcon />}
                                                </IconButton>
                                              </Box>
                                            </TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  </TableContainer>
                                )}
                              </Box>
                            )}
                          </AccordionDetails>
                        </Accordion>
                      </Grid>

                      {/* Advanced Settings Section */}
                      <Grid item xs={12}>
                        <Accordion 
                          expanded={expandedSections.advanced} 
                          onChange={() => handleSectionToggle('advanced')}
                        >
                          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                            <Box display="flex" alignItems="center">
                              <SettingsIcon sx={{ mr: 1, color: 'primary.main' }} />
                              <Typography variant="h6">Advanced Settings</Typography>
                            </Box>
                          </AccordionSummary>
                          <AccordionDetails>
                            <Grid container spacing={3}>
                              {/* Church ID Field */}
                              <Grid item xs={12} md={6}>
                                <TextField
                                  fullWidth
                                  id="church_id"
                                  name="church_id"
                                  label="Church ID"
                                  type="number"
                                  value={formik.values.church_id || id || ''}
                                  onChange={(e) => {
                                    const value = parseInt(e.target.value) || null;
                                    formik.setFieldValue('church_id', value);
                                    handleFieldChange('church_id', value);
                                  }}
                                  onBlur={formik.handleBlur}
                                  error={formik.touched.church_id && Boolean(formik.errors.church_id)}
                                  helperText={
                                    formik.touched.church_id && formik.errors.church_id 
                                      ? formik.errors.church_id 
                                      : "Unique identifier for this church. Must match records in church databases."
                                  }
                                  variant="outlined"
                                  InputProps={{
                                    readOnly: !hasRole(['super_admin']),
                                    sx: { 
                                      backgroundColor: !hasRole(['super_admin']) ? '#f5f5f5' : 'transparent',
                                      '& .MuiInputBase-input': {
                                        cursor: !hasRole(['super_admin']) ? 'not-allowed' : 'text'
                                      }
                                    }
                                  }}
                                />
                                {!hasRole(['super_admin']) && (
                                  <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                    ⚠️ Only Super Admins can modify Church ID
                                  </Typography>
                                )}
                                {isFieldModified.church_id && (
                                  <Alert severity="warning" sx={{ mt: 1 }}>
                                    <strong>⚠️ Important:</strong> Changing the Church ID will affect how records link to this church. 
                                    Make sure the new ID matches existing record data.
                                  </Alert>
                                )}
                              </Grid>

                              {/* Default Landing Page */}
                              <Grid item xs={12} md={6}>
                                <FormControl fullWidth>
                                  <InputLabel>Default Landing Page</InputLabel>
                                  <Select
                                    value={formik.values.default_landing_page || 'church_records'}
                                    onChange={(e) => {
                                      formik.setFieldValue('default_landing_page', e.target.value);
                                      handleFieldChange('default_landing_page', e.target.value);
                                    }}
                                    label="Default Landing Page"
                                  >
                                    <MenuItem value="liturgical_calendar">📅 Liturgical Calendar</MenuItem>
                                    <MenuItem value="church_records">📋 Church Records</MenuItem>
                                    <MenuItem value="notes_app">📝 Notes App</MenuItem>
                                  </Select>
                                </FormControl>
                                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                                  Default application users see when accessing the church system.
                                </Typography>
                              </Grid>

                              {/* Record Types and Counts */}
                              <Grid item xs={12}>
                                <Typography variant="h6" gutterBottom>Record Types & Counts</Typography>
                                {loadingRecords ? (
                                  <Box display="flex" justifyContent="center" p={3}>
                                    <CircularProgress />
                                  </Box>
                                ) : (
                                  <Grid container spacing={2}>
                                    {Object.entries(recordCounts).map(([tableName, count]) => (
                                      <Grid item xs={12} sm={6} md={4} key={tableName}>
                                        <Card variant="outlined">
                                          <CardContent>
                                            <Typography variant="subtitle2" gutterBottom>
                                              {tableName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                            </Typography>
                                            <Typography variant="h4" color="primary">
                                              {count.toLocaleString()}
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                              records
                                            </Typography>
                                          </CardContent>
                                        </Card>
                                      </Grid>
                                    ))}
                                  </Grid>
                                )}
                              </Grid>
                            </Grid>
                          </AccordionDetails>
                        </Accordion>
                      </Grid>

                      {/* Database Settings Section */}
                      <Grid item xs={12}>
                        <Accordion 
                          expanded={expandedSections.database} 
                          onChange={() => handleSectionToggle('database')}
                        >
                          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                            <Box display="flex" alignItems="center">
                              <StorageIcon sx={{ mr: 1, color: 'primary.main' }} />
                              <Typography variant="h6">Database Settings</Typography>
                            </Box>
                          </AccordionSummary>
                          <AccordionDetails>
                            {loadingDatabase ? (
                              <Box display="flex" justifyContent="center" p={3}>
                                <CircularProgress />
                              </Box>
                            ) : (
                              <Box sx={{ p: 2 }}>
                                {/* Header with Status */}
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
                                  <Box sx={{ flex: 1 }}>
                                    <Typography variant="h5" sx={{ fontWeight: 600, mb: 0.5 }}>
                                      Database Management
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                      Manage and monitor your church's database configuration
                                    </Typography>
                                  </Box>
                                  <Button 
                                    variant="contained"
                                    startIcon={<RefreshIcon />}
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      if (id && !loadingDatabase) {
                                        testDatabaseConnection(id);
                                      }
                                    }}
                                    disabled={loadingDatabase || !id}
                                    sx={{ minWidth: 140 }}
                                  >
                                    {loadingDatabase ? 'Testing...' : 'Test Connection'}
                                  </Button>
                                </Box>

                                <Grid container spacing={4}>
                                  {/* Database Overview Card */}
                                  <Grid item xs={12} lg={6}>
                                    <Card sx={{ height: '100%', borderRadius: 3, boxShadow: 3, border: '1px solid', borderColor: 'grey.200' }}>
                                      <CardContent sx={{ p: 3 }}>
                                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                                          <Box sx={{ 
                                            backgroundColor: 'primary.main', 
                                            borderRadius: 2, 
                                            p: 1.5, 
                                            mr: 2,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                          }}>
                                            <StorageIcon sx={{ color: 'white', fontSize: 24 }} />
                                          </Box>
                                          <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                            Database Overview
                                          </Typography>
                                        </Box>
                                        
                                        <Box sx={{ space: 2 }}>
                                          <Box sx={{ 
                                            display: 'flex', 
                                            justifyContent: 'space-between', 
                                            alignItems: 'center',
                                            py: 2.5,
                                            borderBottom: '1px solid',
                                            borderColor: 'grey.100'
                                          }}>
                                            <Typography variant="body1" sx={{ fontWeight: 500, color: 'text.primary' }}>
                                              Database Name
                                            </Typography>
                                            <Chip 
                                              label={databaseInfo?.name || formik.values.database_name || 'Not available'}
                                              color="primary"
                                              variant="filled"
                                              sx={{ fontFamily: 'monospace', fontWeight: 600 }}
                                            />
                                          </Box>
                                          
                                          <Box sx={{ 
                                            display: 'flex', 
                                            justifyContent: 'space-between', 
                                            alignItems: 'center',
                                            py: 2.5,
                                            borderBottom: '1px solid',
                                            borderColor: 'grey.100'
                                          }}>
                                            <Typography variant="body1" sx={{ fontWeight: 500, color: 'text.primary' }}>
                                              Total Tables
                                            </Typography>
                                            <Chip 
                                              label={databaseInfo?.table_count || 0}
                                              color="success"
                                              sx={{ fontWeight: 600, minWidth: 60 }}
                                            />
                                          </Box>
                                          
                                          <Box sx={{ 
                                            display: 'flex', 
                                            justifyContent: 'space-between', 
                                            alignItems: 'center',
                                            py: 2.5,
                                            borderBottom: '1px solid',
                                            borderColor: 'grey.100'
                                          }}>
                                            <Typography variant="body1" sx={{ fontWeight: 500, color: 'text.primary' }}>
                                              Database Size
                                            </Typography>
                                            <Typography variant="h6" sx={{ fontWeight: 600, color: 'text.primary' }}>
                                              {databaseInfo?.size_mb ? `${databaseInfo.size_mb} MB` : 'Unknown'}
                                            </Typography>
                                          </Box>
                                          
                                          <Box sx={{ 
                                            display: 'flex', 
                                            justifyContent: 'space-between', 
                                            alignItems: 'center',
                                            py: 2.5
                                          }}>
                                            <Typography variant="body1" sx={{ fontWeight: 500, color: 'text.primary' }}>
                                              Last Backup
                                            </Typography>
                                            <Typography variant="body1" sx={{ fontWeight: 600, color: 'text.secondary' }}>
                                              {databaseInfo?.last_backup || 'Never'}
                                            </Typography>
                                          </Box>
                                        </Box>
                                      </CardContent>
                                    </Card>
                                  </Grid>

                                  {/* Database Tables Card */}
                                  <Grid item xs={12} lg={6}>
                                    <Card sx={{ height: '100%', borderRadius: 3, boxShadow: 3, border: '1px solid', borderColor: 'grey.200' }}>
                                      <CardContent sx={{ p: 3 }}>
                                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                                          <Box sx={{ 
                                            backgroundColor: 'secondary.main', 
                                            borderRadius: 2, 
                                            p: 1.5, 
                                            mr: 2,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                          }}>
                                            <HistoryIcon sx={{ color: 'white', fontSize: 24 }} />
                                          </Box>
                                          <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                            Record Tables
                                          </Typography>
                                        </Box>
                                        
                                        {databaseInfo?.tables && databaseInfo.tables.length > 0 ? (
                                          <Box sx={{ maxHeight: 340, overflowY: 'auto' }}>
                                            {databaseInfo.tables
                                              .filter(table => table.name.includes('_records') || table.name.includes('_history'))
                                              .sort((a, b) => b.rows - a.rows)
                                              .map((table, index, filteredTables) => (
                                              <Box key={index} sx={{ 
                                                display: 'flex', 
                                                justifyContent: 'space-between', 
                                                alignItems: 'center',
                                                py: 2.5,
                                                borderBottom: index < filteredTables.length - 1 ? '1px solid' : 'none',
                                                borderColor: 'grey.100'
                                              }}>
                                                <Box>
                                                  <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
                                                    {table.name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                                  </Typography>
                                                  <Typography variant="caption" color="text.secondary">
                                                    {table.size_mb ? `${table.size_mb} MB` : 'Size unknown'}
                                                  </Typography>
                                                </Box>
                                                <Chip 
                                                  label={`${table.rows || 0} records`}
                                                  size="medium"
                                                  color={table.rows > 0 ? 'primary' : 'default'}
                                                  variant={table.rows > 0 ? 'filled' : 'outlined'}
                                                  sx={{ fontWeight: 600, minWidth: 100 }}
                                                />
                                              </Box>
                                            ))}
                                          </Box>
                                        ) : (
                                          <Box sx={{ 
                                            textAlign: 'center', 
                                            py: 6,
                                            color: 'text.secondary' 
                                          }}>
                                            <StorageIcon sx={{ fontSize: 48, mb: 2, opacity: 0.3 }} />
                                            <Typography variant="body1" sx={{ fontWeight: 500 }}>
                                              No record tables found
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                              Tables will appear here once data is added
                                            </Typography>
                                          </Box>
                                        )}
                                      </CardContent>
                                    </Card>
                                  </Grid>

                                  {/* Backup & Maintenance Section */}
                                  <Grid item xs={12}>
                                    <Card sx={{ borderRadius: 3, boxShadow: 3, border: '1px solid', borderColor: 'grey.200' }}>
                                      <CardContent sx={{ p: 4 }}>
                                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
                                          <Box sx={{ 
                                            backgroundColor: 'warning.main', 
                                            borderRadius: 2, 
                                            p: 1.5, 
                                            mr: 2,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                          }}>
                                            <ScheduleIcon sx={{ color: 'white', fontSize: 24 }} />
                                          </Box>
                                          <Box sx={{ flex: 1 }}>
                                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                              Backup & Maintenance
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                              Automated backup schedule and database maintenance
                                            </Typography>
                                          </Box>
                                        </Box>
                                        
                                        <Grid container spacing={3} sx={{ mb: 4 }}>
                                          <Grid item xs={12} md={4}>
                                            <Box sx={{ textAlign: 'center', p: 3, backgroundColor: 'grey.50', borderRadius: 3, border: '1px solid', borderColor: 'grey.100' }}>
                                              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ fontWeight: 600 }}>
                                                Backup Frequency
                                              </Typography>
                                              <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                                                Daily at 2:00 AM
                                              </Typography>
                                            </Box>
                                          </Grid>
                                          <Grid item xs={12} md={4}>
                                            <Box sx={{ textAlign: 'center', p: 3, backgroundColor: 'grey.50', borderRadius: 3, border: '1px solid', borderColor: 'grey.100' }}>
                                              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ fontWeight: 600 }}>
                                                Retention Period
                                              </Typography>
                                              <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                                                30 Days
                                              </Typography>
                                            </Box>
                                          </Grid>
                                          <Grid item xs={12} md={4}>
                                            <Box sx={{ textAlign: 'center', p: 3, backgroundColor: 'grey.50', borderRadius: 3, border: '1px solid', borderColor: 'grey.100' }}>
                                              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ fontWeight: 600 }}>
                                                Backup Status
                                              </Typography>
                                              <Chip 
                                                label="Active"
                                                color="success"
                                                sx={{ fontWeight: 700, fontSize: '1rem', py: 1 }}
                                              />
                                            </Box>
                                          </Grid>
                                        </Grid>
                                        
                                        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', justifyContent: 'center' }}>
                                          <Button 
                                            variant="contained"
                                            startIcon={<RefreshIcon />}
                                            size="large"
                                            sx={{ minWidth: 160, py: 1.5 }}
                                          >
                                            Backup Now
                                          </Button>
                                          <Button 
                                            variant="outlined"
                                            startIcon={<HistoryIcon />}
                                            size="large"
                                            sx={{ minWidth: 160, py: 1.5 }}
                                          >
                                            View Change Log
                                          </Button>
                                        </Box>

                                        {/* Database Change Log Preview */}
                                        <Box sx={{ mt: 4, pt: 3, borderTop: '1px solid', borderColor: 'grey.200' }}>
                                          <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                                            Recent Changes
                                          </Typography>
                                          {databaseLogs.length === 0 ? (
                                            <Box sx={{ 
                                              textAlign: 'center', 
                                              py: 4,
                                              backgroundColor: 'info.light',
                                              borderRadius: 2,
                                              color: 'info.contrastText'
                                            }}>
                                              <HistoryIcon sx={{ fontSize: 40, mb: 1, opacity: 0.7 }} />
                                              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                                                No database changes recorded yet
                                              </Typography>
                                              <Typography variant="body2" sx={{ opacity: 0.8 }}>
                                                Changes will be tracked here automatically
                                              </Typography>
                                            </Box>
                                          ) : (
                                            <TableContainer component={Paper} sx={{ borderRadius: 2, boxShadow: 1 }}>
                                              <Table>
                                                <TableHead sx={{ backgroundColor: 'grey.50' }}>
                                                  <TableRow>
                                                    <TableCell sx={{ fontWeight: 600 }}>Date</TableCell>
                                                    <TableCell sx={{ fontWeight: 600 }}>Change Type</TableCell>
                                                    <TableCell sx={{ fontWeight: 600 }}>Table</TableCell>
                                                    <TableCell sx={{ fontWeight: 600 }}>Description</TableCell>
                                                    <TableCell sx={{ fontWeight: 600 }}>User</TableCell>
                                                  </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                  {databaseLogs.slice(0, 5).map((log, index) => (
                                                    <TableRow key={index} sx={{ '&:hover': { backgroundColor: 'grey.50' } }}>
                                                      <TableCell>
                                                        {new Date(log.timestamp).toLocaleString()}
                                                      </TableCell>
                                                      <TableCell>
                                                        <Chip 
                                                          label={log.change_type} 
                                                          size="small" 
                                                          color={
                                                            log.change_type === 'CREATE' ? 'success' :
                                                            log.change_type === 'ALTER' ? 'warning' :
                                                            log.change_type === 'DROP' ? 'error' : 'default'
                                                          }
                                                        />
                                                      </TableCell>
                                                      <TableCell sx={{ fontFamily: 'monospace' }}>{log.table_name}</TableCell>
                                                      <TableCell>{log.description}</TableCell>
                                                      <TableCell>{log.user_email}</TableCell>
                                                    </TableRow>
                                                  ))}
                                                </TableBody>
                                              </Table>
                                            </TableContainer>
                                          )}
                                        </Box>
                                      </CardContent>
                                    </Card>
                                  </Grid>
                                </Grid>
                              </Box>
                            )}
                          </AccordionDetails>
                        </Accordion>
                      </Grid>
                    </>
                  )}

                  {/* Action Buttons */}
                  <Grid item xs={12}>
                    <Divider sx={{ my: 3 }} />
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                      <Button
                        variant="outlined"
                        onClick={handleBackClick}
                        disabled={loading}
                      >
                        Cancel
                      </Button>

                      <Box display="flex" gap={2}>
                        {isEdit && (
                          <Button
                            variant="outlined"
                            color="error"
                            startIcon={<IconTrash />}
                            disabled={loading}
                            onClick={async () => {
                              // Log delete attempt
                              logger.info('Church Management', 'Church delete confirmation requested', {
                                churchId: id,
                                churchName: formik.values.name,
                                userAction: 'church_delete_confirm_request'
                              });
                              
                              if (window.confirm('Are you sure you want to delete this church?')) {
                                logger.info('Church Management', 'Church delete confirmed', {
                                  churchId: id,
                                  churchName: formik.values.name,
                                  userAction: 'church_delete_confirmed'
                                });
                                try {
                                  await adminAPI.churches.removeAllUsers(parseInt(id));
                                  await adminAPI.churches.delete(parseInt(id));
                                  navigate('/apps/church-management');
                                } catch (err) {
                                  setError('Cannot delete church with assigned users. Please remove all users from this church first.');
                                }
                              } else {
                                logger.info('Church Management', 'Church delete cancelled', {
                                  churchId: id,
                                  churchName: formik.values.name,
                                  userAction: 'church_delete_cancelled'
                                });
                              }
                            }}
                          >
                            Delete
                          </Button>
                        )}

                        <Button
                          type="submit"
                          variant="contained"
                          startIcon={loading ? <CircularProgress size={20} /> : <IconDeviceFloppy />}
                          disabled={loading}
                        >
                          {loading ? 'Saving...' : (isEdit ? 'Update Church' : 'Create Church')}
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </form>
            </Grid>
          )}
        </Grid>

        {/* User Management Dialog */}
        <Dialog 
          open={userDialog.open} 
          onClose={() => setUserDialog({ open: false, user: null, action: '' })}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            {userDialog.action === 'add' ? 'Add New User' : 'Edit User'}
          </DialogTitle>
          <DialogContent>
            <UserManagementDialog
              user={userDialog.user}
              action={userDialog.action}
              churchId={id}
              onSave={(userData) => {
                handleUserSave(userData);
                setUserDialog({ open: false, user: null, action: '' });
              }}
              onCancel={() => setUserDialog({ open: false, user: null, action: '' })}
            />
          </DialogContent>
        </Dialog>

        {/* Password Reset Dialog */}
        <Dialog
          open={passwordResetDialog.open}
          onClose={() => setPasswordResetDialog({ open: false, user: null })}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>Reset Password</DialogTitle>
          <DialogContent>
            <Typography variant="body1" sx={{ mb: 2 }}>
              Are you sure you want to reset the password for {passwordResetDialog.user?.email}?
            </Typography>
            <Alert severity="warning" sx={{ mb: 2 }}>
              This will generate a new temporary password that must be communicated to the user.
            </Alert>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setPasswordResetDialog({ open: false, user: null })}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                handlePasswordReset(passwordResetDialog.user);
                setPasswordResetDialog({ open: false, user: null });
              }}
              variant="contained"
              color="warning"
            >
              Reset Password
            </Button>
          </DialogActions>
        </Dialog>
      </PageContainer>
    );
  };

  export default ChurchForm;
